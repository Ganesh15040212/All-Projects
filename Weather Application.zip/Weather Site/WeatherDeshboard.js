
const cityInput = document.querySelector(".city-input")
const searchButton = document.querySelector(".search-btn")
const locationButton = document.querySelector(".location-btn")
const currentWeather = document.querySelector(".current-weather")
const weatherCardDiv = document.querySelector(".weather-cards")

const API_KEY = "be77fca2ba7832430cba514ac205adc6"  // API key for openweathermap API

const createWeatherCard = (cityName, weatherItem, index) => {
    if (index === 0)   // HTML for the main weather card
    {
        return `<div class="col-12">
                    <div class="p-4 d-flex shadow-lg rounded-5 text-dark" style="background: transparent; backdrop-filter: blur(10px);">
                        <div class="details d-grid flex-grow-1 ms-3">
                            <h2 class="mb-4">${cityName} ( ${weatherItem.dt_txt.split(" ")[0]} )</h2>
                            <h5>Temperature : <span>${(weatherItem.main.temp - 273.15).toFixed(2)}</span> ° C</h5>
                            <h5>Wind : <span>${weatherItem.wind.speed}</span> M/S</h5>
                            <h5>Humidity : <span>${weatherItem.main.humidity}</span> %</h5>
                        </div>
                        <div class="icon flex-shrink-1 me-5">
                            <img src="https://openweathermap.org/img/wn/${weatherItem.weather[0].icon}@4x.png" alt="Weather-icon">
                            <h4 class = "text-center"><span>${weatherItem.weather[0].description}</span></h4>
                        </div>
                    </div>
                </div>`
    }
    else    // HTML for the other days forecast card
    {
        return `<li class="col-md-3 p-1 mt-5 shadow-lg rounded-4" style="background: transparent; backdrop-filter: blur(10px);">
                    <h3 class="mt-3">( ${weatherItem.dt_txt.split(" ")[0]} )</h3>
                    <img src="https://openweathermap.org/img/wn/${weatherItem.weather[0].icon}@2x.png" alt="Weather-icon" class="mx-4">
                    <h5><span>${weatherItem.weather[0].description}</span></h5>
                    <h6>Temperature : <span>${(weatherItem.main.temp - 273.15).toFixed(2)}</span> ° C</h6>
                    <h6>Wind : <span>${weatherItem.wind.speed}</span> M/S</h6>
                    <h6>Humidity : <span>${weatherItem.main.humidity}</span> %</h6>
                </li>`
    }
}

const getWeatherDeatils = (cityName, lat, lon) => {
    const WEATHER_API_URL = `http://api.openweathermap.org/data/2.5/forecast/?lat=${lat}&lon=${lon}&appid=${API_KEY}`

    fetch(WEATHER_API_URL).then(res => res.json()).then(data => {
        const uniqueForecastDays = []
        const fiveDaysForecast = data.list.filter(forecast => {
            const forecastDate = new Date(forecast.dt_txt).getDate()
            if (!uniqueForecastDays.includes(forecastDate)) {
                return uniqueForecastDays.push(forecastDate)
            }
        })

        // Clearing previous weather data
        cityInput.value = ""
        weatherCardDiv.innerHTML = ""
        currentWeather.innerHTML = ""

        // console.log(fiveDaysForecast)

        // Creating weather cards and adding them to the DOM
        fiveDaysForecast.forEach((weatherItem, index) => {
            const cardHTML = createWeatherCard(cityName, weatherItem, index);
            if (index === 0) {
                currentWeather.innerHTML = cardHTML; // For today's weather
            }
            else {
                weatherCardDiv.insertAdjacentHTML("beforeend", cardHTML); // For 5-day forecast
            }
        });

    })
        .catch(() => {
            alert("An Error occured while featching the weather forecast!")
        })
}

const getCityCoordinates = () => {
    const cityName = cityInput.value.trim()
    if (!cityName)
        return;
    // console.log(cityName);
    const GEOCODING_API_URL = `http://api.openweathermap.org/geo/1.0/direct?q=${cityName}&limit=1&appid=${API_KEY}`

    fetch(GEOCODING_API_URL).then(res => res.json()).then(data => {
        if (!data.length)
            return alert(`No Coordinates found for ${cityName}`)
        const { name, lat, lon } = data[0]
        getWeatherDeatils(name, lat, lon)
        // console.log(data)
    })
        .catch(() => {
            alert("An Error occured while featching the Coordinates!")
        })
}

const getUserCoordinates = () => {
    navigator.geolocation.getCurrentPosition(
        position => {
            const { latitude, longitude } = position.coords
            const REVERSE_GEOCODING_URL = `http://api.openweathermap.org/geo/1.0/reverse?lat=${latitude}&lon=${longitude}&limit=1&appid=${API_KEY}`

            // get city name from coordinates using reverse geocoding API
            fetch(REVERSE_GEOCODING_URL).then(res => res.json()).then(data => {
                const { name } = data[0]
                getWeatherDeatils(name, latitude, longitude)
                // console.log(data)
            })
                .catch(() => {
                    alert("An Error occured while featching the city!")
                })
            // console.log(position);
        },
        error => {
            if (error.code === error.PERMISSION_DENIED) {
                alert("Geolocation request denied. please reset location permission to grant access again..")
            }
            // console.log(error);
        }
    )
}

locationButton.addEventListener('click', getUserCoordinates)

searchButton.addEventListener('click', () => {
    getCityCoordinates()
})
cityInput.addEventListener('keypress', (e) => {
    if (e.key === "Enter")
        searchButton.click()
})
